#!/usr/bin/env python3
"""
Script to remove uncited references from a BibTeX file.
Usage: python bib_cleaner.py
"""

import re
import os

def extract_citations_from_tex(tex_files):
    """Extract all citation keys from tex files"""
    citations = set()
    
    for tex_file in tex_files:
        if os.path.exists(tex_file):
            print(f"Processing {tex_file}...")
            with open(tex_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Find all citation commands
            cite_patterns = [
                r'\\cite\{([^}]+)\}',
                r'\\citep\{([^}]+)\}', 
                r'\\citet\{([^}]+)\}',
                r'\\citeauthor\{([^}]+)\}',
                r'\\citeyear\{([^}]+)\}'
            ]
            
            for pattern in cite_patterns:
                matches = re.findall(pattern, content)
                for match in matches:
                    # Handle multiple keys in one cite command
                    keys = [key.strip() for key in match.split(',')]
                    citations.update(keys)
        else:
            print(f"Warning: {tex_file} not found")
    
    return citations

def extract_bib_entries(bib_file, cited_keys):
    """Extract only cited bibliography entries"""
    print(f"Processing bibliography file: {bib_file}")
    
    with open(bib_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Split into entries - look for @ at start of line or after newline
    entries = re.split(r'\n(?=@)', content)
    cited_entries = []
    found_keys = set()
    
    for entry in entries:
        # Skip empty entries
        if not entry.strip():
            continue
            
        # Ensure entry starts with @
        if not entry.strip().startswith('@'):
            entry = '@' + entry
            
        # Extract the key from the entry
        key_match = re.search(r'@\w+\s*\{\s*([^,\s}]+)', entry)
        if key_match:
            key = key_match.group(1).strip()
            if key in cited_keys:
                cited_entries.append(entry.strip())
                found_keys.add(key)
                print(f"  Found cited entry: {key}")
    
    # Check for missing citations
    missing = cited_keys - found_keys
    if missing:
        print(f"\nWarning: Could not find bib entries for: {missing}")
    
    return '\n\n'.join(cited_entries)

def main():
    # Files to scan for citations
    tex_files = [
        'sections/intro.tex', 
        'sections/related.tex',
        'sections/abstract.tex',  # in case there are citations in abstract
        'sections/plan.tex'       # in case there are citations in action plan
    ]
    
    # Extract citations
    print("Extracting citations from LaTeX files...")
    cited_keys = extract_citations_from_tex(tex_files)
    print(f"\nFound {len(cited_keys)} unique citations:")
    for key in sorted(cited_keys):
        print(f"  - {key}")
    
    if not cited_keys:
        print("No citations found! Check your tex files.")
        return
    
    # Process bibliography
    bib_file = 'project_template.bib'
    if not os.path.exists(bib_file):
        print(f"Error: {bib_file} not found!")
        return
    
    # Create backup
    backup_file = 'project_template.bib.backup'
    if not os.path.exists(backup_file):
        print(f"Creating backup: {backup_file}")
        with open(bib_file, 'r') as src, open(backup_file, 'w') as dst:
            dst.write(src.read())
    
    # Extract only cited entries
    filtered_bib = extract_bib_entries(bib_file, cited_keys)
    
    # Save filtered bibliography
    output_file = 'project_template_clean.bib'
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(filtered_bib)
    
    print(f"\nFiltered bibliography saved to: {output_file}")
    print(f"Original file backed up as: {backup_file}")
    print(f"\nTo use the cleaned bibliography:")
    print(f"  mv {output_file} {bib_file}")
    
if __name__ == "__main__":
    main()